package br.com.laudos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaudosApplicationTests {

	@Test
	void contextLoads() {
	}

}
