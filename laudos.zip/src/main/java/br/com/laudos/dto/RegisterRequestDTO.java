package br.com.laudos.dto;

public record RegisterRequestDTO(String nome, String email, String password){ }
