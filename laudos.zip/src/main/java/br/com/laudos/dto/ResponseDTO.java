package br.com.laudos.dto;

public record ResponseDTO(String nome, String token) { }
