package br.com.laudos.dto;

public record LoginRequestDTO(String email, String password) { }
